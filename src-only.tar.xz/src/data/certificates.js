const certificates=[

{

title:"Ceritificates of Completion of Internship",

image:"../assets/Rhombox.jpg"

},

{

title:"Aws Course Completion Certificate",

image:"../../aws.png"

}

]

export default certificates;