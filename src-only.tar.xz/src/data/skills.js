import {
  FaHtml5,
  FaCss3Alt,
  FaGitAlt,
  FaDocker,
  FaAws,
  FaJenkins,
} from "react-icons/fa";
import {
  SiLinux,
  SiKubernetes,
  SiGithub,
  SiGithubactions,
  SiArgo,
  SiPrometheus,
  SiGrafana,
  SiHelm,
  SiGnubash,
  SiPython,
  SiCplusplus,
  SiOdoo,
} from "react-icons/si";

const skills = [
  { name: "HTML", icon: FaHtml5, type: "component" },
  { name: "CSS", icon: FaCss3Alt, type: "component" },
  { name: "Linux", icon: SiLinux, type: "component" },
  { name: "Docker", icon: FaDocker, type: "component" },
  { name: "Kubernetes", icon: SiKubernetes, type: "component" },
  { name: "Git", icon: FaGitAlt, type: "component" },
  { name: "GitHub", icon: SiGithub, type: "component" },
  { name: "GitHub Actions", icon: SiGithubactions, type: "component" },
  { name: "Jenkins", icon: FaJenkins, type: "component" },
  { name: "Prometheus", icon: SiPrometheus, type: "component" },
  { name: "Grafana", icon: SiGrafana, type: "component" },
  { name: "Helm", icon: SiHelm, type: "component" },
  { name: "ArgoCD", icon: SiArgo, type: "component" },
  { name: "AWS", icon: FaAws, type: "component" },
  { name: "Shell Scripting", icon: SiGnubash, type: "component" },
  { name: "Python", icon: SiPython, type: "component" },
  { name: "C++", icon: SiCplusplus, type: "component" },
  { name: "Odoo", icon: SiOdoo, type: "component" },

  // AWS services - SVG file paths (place files in /public/icons/aws/)
  { name: "EC2", icon: "/icons/aws/ec2.svg", type: "image" },
  { name: "IAM", icon: "/icons/aws/iam.svg", type: "image" },
  { name: "RDS", icon: "/icons/aws/rds.svg", type: "image" },
  { name: "VPC", icon: "/icons/aws/vpc.svg", type: "image" },
  { name: "DynamoDB", icon: "/icons/aws/dynamodb.svg", type: "image" },
  { name: "Lambda", icon: "/icons/aws/lambda.svg", type: "image" },
  { name: "Route 53", icon: "/icons/aws/route53.svg", type: "image" },
  { name: "ECR", icon: "/icons/aws/ecr.svg", type: "image" },
  { name: "ECS", icon: "/icons/aws/ecs.svg", type: "image" },
];

export default skills;